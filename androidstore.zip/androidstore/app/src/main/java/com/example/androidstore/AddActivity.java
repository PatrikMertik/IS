package com.example.androidstore;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import com.android.volley.AuthFailureError;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

public class AddActivity extends AppCompatActivity {
    private RequestQueue requestQueue;
    private TextView status;
    private EditText imeEt;
    private EditText priimekEt;
    private EditText emailEt;
    private EditText uimeEt;
    private EditText gesloEt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);
        requestQueue = Volley.newRequestQueue(getApplicationContext());
        // Get the Intent that started this activity and extract the string
        Intent intent = getIntent();
        String message = intent.getStringExtra(MainActivity.EXTRA_MESSAGE);
        // Capture the layout's TextView and set the string as its text
        status = (TextView) findViewById(R.id.status);
        status.setText(message);
        imeEt = (EditText) findViewById(R.id.editText);
        priimekEt = (EditText) findViewById(R.id.editText2);
        emailEt = (EditText) findViewById(R.id.editText3);
        uimeEt = (EditText) findViewById(R.id.editText4);
        gesloEt = (EditText) findViewById(R.id.editText5);
    }
    public void dodajOsebo(View view) {
        String URL = "https://api20200104091749.azurewebsites.net/api/Admins";
        this.status.setText("Dodajam v " + URL);
        try {
            JSONObject jsonBody = new JSONObject();
            jsonBody.put("name", imeEt.getText());
            jsonBody.put("surname", priimekEt.getText());
            jsonBody.put("email", emailEt.getText());
            jsonBody.put("username", uimeEt.getText());
            jsonBody.put("password", gesloEt.getText());
            final String mRequestBody = jsonBody.toString();
            status.setText(mRequestBody);
            StringRequest stringRequest = new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    Log.i("LOG_VOLLEY", response);
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Log.e("LOG_VOLLEY", error.toString());
                }
            }) {
                @Override
                public String getBodyContentType() {
                    return "application/json; charset=utf-8";
                }
                @Override
                public byte[] getBody() throws AuthFailureError {
                    try {
                        return mRequestBody == null ? null : mRequestBody.getBytes("utf-8");
                    } catch (UnsupportedEncodingException uee) {
                        VolleyLog.wtf("Unsupported Encoding while trying to get the bytes of %s using %s", mRequestBody, "utf-8");
                        return null;
                    }
                }

                @Override
                public Map<String,String> getHeaders() throws AuthFailureError {
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("Content-Type","application/json");
                    params.put("ApiKey","SecretKey");
                    return params;
                }

                @Override
                protected Response<String> parseNetworkResponse(NetworkResponse response) {
                    String responseString = "";
                    if (response != null) {
                        responseString = String.valueOf(response.statusCode);
                        status.setText(responseString);
                    }
                    return Response.success(responseString, HttpHeaderParser.parseCacheHeaders(response));
                }
            };
            requestQueue.add(stringRequest);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}