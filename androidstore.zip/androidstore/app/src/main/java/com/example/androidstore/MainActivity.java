package com.example.androidstore;
import android.content.Intent;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    private RequestQueue requestQueue;
    private TextView osebe;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        requestQueue = Volley.newRequestQueue(getApplicationContext());
        osebe = (TextView) findViewById(R.id.osebe);
    }

    private Response.Listener<JSONArray> jsonArrayListener = new Response.Listener<JSONArray>() {
        @Override
        public void onResponse(JSONArray response) {
            ArrayList<String> data = new ArrayList<>();
            for (int i = 0; i < response.length(); i++) {
                try {
                    JSONObject object = response.getJSONObject(i);
                    String id = object.getString("id");
                    String ime = object.getString("name");
                    String priimek = object.getString("surname");
                    String enaslov = object.getString("email");
                    String uporabime = object.getString("username");
                    String geslo = object.getString("password");
                    data.add(ime + " "  + priimek + " " + enaslov + " " + uporabime);
                } catch (JSONException e) {
                    e.printStackTrace();
                    return;
                }
            }
            osebe.setText("");
            osebe.setMovementMethod(new ScrollingMovementMethod());
            for (String row: data) {
                String currentText = osebe.getText().toString();
                osebe.setText(currentText + "\n\n" + row);
            }
        }
    };


    private Response.ErrorListener errorListener = new Response.ErrorListener() {
        @Override
        public void onErrorResponse(VolleyError error) {
            Log.d("REST error", error.getMessage());
        }
    };



    public void prikaziOsebe(View view) {
        if (view != null) {
            TextView textView = (TextView) view;
            String url = "https://api20200104091749.azurewebsites.net/api/Admins";
            JsonArrayRequest request = new JsonArrayRequest(url, jsonArrayListener, errorListener){
                @Override
                public Map<String,String> getHeaders() throws AuthFailureError {
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("ApiKey","SecretKey");
                    return params;
                }
            };
            requestQueue.add(request);
        }
    }

    public static final String EXTRA_MESSAGE = "com.example.androidstore.MESSAGE";
    public void addPerson(View view) {
        // Do something in response to button
        Intent intent = new Intent(this, AddActivity.class);
        String message = "Dodaj osebo v seznam.";
        intent.putExtra(EXTRA_MESSAGE, message);
        startActivity(intent);
    }

}